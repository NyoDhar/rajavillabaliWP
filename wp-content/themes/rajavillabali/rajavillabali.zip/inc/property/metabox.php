<?php
add_action("admin_init", "rvb_add_meta_box");
function rvb_add_meta_box(){
	add_meta_box("property-details", "Property Details", "rvb_property_details", "mphb_room_type", "normal", "high");
	add_meta_box("property-location", "Property Location", "rvb_property_location", "mphb_room_type", "normal", "default");
	add_meta_box("hot-deal-meta", "Settings", "rvb_hot_deal_setting", "hot-deal", "normal", "default");
}
function rvb_property_details($post){
	$metas = get_post_meta($post->ID);
	?>
	<table class="form-table">
		<tr>
			<th><label>Bedrooms</label></th>
			<td>
				<input type="number" name="rvb_bedrooms" value="<?php echo $metas['rvb_bedrooms'][0] ?>">
			</td>
		</tr>
		<tr>
			<th><label>Property Photos</label></th>
			<td>
				Click the button below to upload the images.
				<?php echo do_shortcode('[ez_wp_media_uploader wrapper_id="rvb-property-photos" field_name="rvb_property_photos" post_id="'.$post->ID.'" ]'); ?>
			</td>
		</tr>
	</table>
	
	<p class="rvb-metabox-title">Property Contact</p>
	<table class="form-table">
		<tr>
			<th><label>Customer Support Phone</label></th>
			<td>
				<input type="text" name="rvb_property_contact_phone" value="<?php echo $metas['rvb_property_contact_phone'][0] ?>" class="regular-text">
			</td>
		</tr>
		<tr>
			<th><label>Customer Support Email</label></th>
			<td>
				<input type="email" name="rvb_property_contact_email" value="<?php echo $metas['rvb_property_contact_email'][0] ?>" class="regular-text">
			</td>
		</tr>
		<tr>
			<th><label>New Booking Email Receiver</label></th>
			<td>
				<input type="email" name="rvb_property_contact_new_booking_email" value="<?php echo $metas['rvb_property_contact_new_booking_email'][0] ?>" class="regular-text">
			</td>
		</tr>
	</table>
	<?php
}

function rvb_property_location($post){
	echo do_shortcode('[blk_map post_id="'.$post->ID.'" meta_key="pinpoint"]');
}

function rvb_hot_deal_setting($post){
	$metas = get_post_meta($post->ID); 
	?>
	<table class="form-table">
		<tr>
			<th><label>Date End</label></th>
			<td>
				<input type="text" name="rvb_hd_date_end" class="rvb-datepicker" value="<?php echo $metas['rvb_hd_date_end'][0] ?>">
			</td>
		</tr>
		<tr>
			<th><label>Discount ( % )</label></th>
			<td>
				<input type="text" name="rvb_hd_date_discount" value="<?php echo $metas['rvb_hd_date_discount'][0] ?>">
			</td>
		</tr>
		<tr>
			<th><label>Properties</label></th>
			<td>
				<input type="text" id="rvb_hd_properties_search" class="regular-text">
				<input type="hidden" id="rvb_hd_properties_search_id">
				<input type="button" class="button button-primary" id="rvb_hd_add" value="Add">
				
				<ul id="rvb_hd_properties">
					<?php
						if(!empty( $metas['rvb_hd_properties'][0] )){
							$properties = unserialize( $metas['rvb_hd_properties'][0] );
							if(!empty($properties)){
								foreach($properties as $p){
									?>
									<li>
										<input type="hidden" name="rvb_hd_properties[]" value="<?php echo $p ?>">
										<?php echo get_the_title($p) ?>
										<span class="remove">&times;</span>
									</li>
									<?php
								}
							}
						}
					?>
				</ul>
			</td>
		</tr>
	</table>
	<?php
}


add_action( 'save_post', 'rvb_save_meta_fields_value', 10, 2 );
function rvb_save_meta_fields_value($post_id, $post){
	global $pagenow;
	if ( 'post.php' != $pagenow ) return $post_id;
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}

	if($_POST['post_type']=='mphb_room_type'){
		update_post_meta($post_id,'rvb_bedrooms',$_POST['rvb_bedrooms']);
		update_post_meta($post_id,'rvb_property_photos',$_POST['rvb_property_photos']);
		update_post_meta($post_id,'pinpoint',$_POST['pinpoint']);
		update_post_meta($post_id,'rvb_property_contact_email',$_POST['rvb_property_contact_email']);
		update_post_meta($post_id,'rvb_property_contact_phone',$_POST['rvb_property_contact_phone']);
		update_post_meta($post_id,'rvb_property_contact_new_booking_email',$_POST['rvb_property_contact_new_booking_email']);
		set_post_thumbnail($post_id, $_POST['rvb_property_photos'][0]);
	}
	
	if($_POST['post_type']=='hot-deal'){
		update_post_meta($post_id,'rvb_hd_date_end',$_POST['rvb_hd_date_end']);
		update_post_meta($post_id,'rvb_hd_date_discount',$_POST['rvb_hd_date_discount']);
		update_post_meta($post_id,'rvb_hd_properties',$_POST['rvb_hd_properties']);
		
		if($post->post_status == 'publish'){
			if(!empty($_POST['rvb_hd_properties'])){
				foreach($_POST['rvb_hd_properties'] as $p){
					update_post_meta($p, 'hot_deal', $post_id );
				}
			}
			
		}
	}
}

