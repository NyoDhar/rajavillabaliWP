<?php
include_once('settings.php');

add_action('admin_head', 'hide_some_admin');
function hide_some_admin(){
	?>
	<style>
		.postbox-container #rooms,
		.postbox-container #reviews,
		.postbox-container #mphb_gallery,
		.postbox-container #mphb_other,
		.postbox-container #mphb_services,
		.postbox-container #heateor_sss_meta,
		#menu-posts-mphb_room_type ul.wp-submenu li:nth-child(10),
		#menu-posts-mphb_room_type ul.wp-submenu li:nth-child(11),
		#menu-posts-mphb_room_type ul.wp-submenu li:nth-child(12){
			display: none;
		}
	</style>
	<?php
}

add_action('wp_footer', 'rvb_ajax_vars');
function rvb_ajax_vars(){
	?>
	<script>
		var ajaxurl = '<?php echo admin_url( 'admin-ajax.php' ); ?>';
	</script>
	<?php
}

add_action('admin_footer', 'rvb_admin_js_vars');
function rvb_admin_js_vars(){
	?>
	<script>
		var progressPath = "<?php echo get_template_directory_uri().'/progress.json'; ?>";
		console.log(progressPath);
	</script>
	<?php
}

/*******************************
Add Custom Post type
*******************************/
add_action( 'init', 'addCustomPostType' );
function addCustomPostType() {
	$theme_text_domain='insti'; /*** Remember to adjust **/
	
	/*** Define custom post type properties in array */
	$posts_type=array(
		'hot-deal' => array(
								'singular_name' => 'Hot Deal',
								'plural_name'	=> 'Hot Deals',
								'public'		=> true,
								'supports'		=> array( 'title', 'thumbnail' ), //Posible value: false (for no support), title, editor, author, thumbnail, excerpt, trackbacks, custom-fields, comments, revisions, page-attributes, post-formats
							),
	);

	/*** Register custom post type in loop based on $posts_type value */
	foreach($posts_type as $key=>$val){
		$labels = array(
			'name'               => _x( $val['plural_name'], 'post type general name', $theme_text_domain ),
			'singular_name'      => _x( $val['singular_name'], 'post type singular name', $theme_text_domain ),
			'add_new'            => _x( 'Add New', $val['singular_name'], $theme_text_domain ),
			'add_new_item'       => __( 'Add New '.$val['singular_name'], $theme_text_domain ),
			'new_item'           => __( 'New '.$val['singular_name'], $theme_text_domain ),
			'edit_item'          => __( 'Edit '.$val['singular_name'], $theme_text_domain ),
			'view_item'          => __( 'View '.$val['singular_name'], $theme_text_domain ),
			'all_items'          => __( 'All '.$val['singular_name'], $theme_text_domain ),
			'search_items'       => __( 'Search '.$val['singular_name'], $theme_text_domain ),
			'parent_item_colon'  => __( 'Parent '.$val['singular_name'].':', $theme_text_domain ),
			'not_found'          => __( 'No '.$val['plural_name'].' found.', $theme_text_domain ),
			'not_found_in_trash' => __( 'No '.$val['plural_name'].' found in Trash.', $theme_text_domain )
		);

		$args = array(
			'labels'             => $labels,
			'public'             => $val['public'],
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'rewrite'            => array( 'slug' => $key ),
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => false,
			'menu_position'      => 5,
			'supports'           => $val['supports']
		);

		register_post_type( $key, $args );
	}
}

add_action('mphb_sc_search_results_before_loop', 'add_villa_search_form');
add_action('blk_before_archieve_property_loop', 'add_villa_search_form');
function add_villa_search_form(){
	?>
		<a href="#" class="button open-change-search" data-text="<?php _e('Change Search', 'rajavillabali'); ?>" data-cancel="<?php _e('Cancel Change', 'rajavillabali'); ?>">
			<?php _e('Change Search', 'rajavillabali'); ?>
		</a>
		<div class="change-search tmp-hide">
	<?php
			echo do_shortcode('[mphb_availability_search attributes="location"]');
	?>
		</div>
	<?php
}

add_action('mphb_sc_search_results_before_loop', 'add_property_list_wrapper_open');
add_action('mphb_sc_rooms_before_loop', 'add_property_list_wrapper_open');
function add_property_list_wrapper_open(){
	echo '<div class="rvb-properties row">';
}

add_action('mphb_sc_search_results_after_loop', 'add_property_list_wrapper_close');
add_action('mphb_sc_rooms_after_loop', 'add_property_list_wrapper_close');
function add_property_list_wrapper_close(){
	echo '</div>';
}

/* function custom_excerpt_length( $length ) {
	return 20;
}
add_filter( 'excerpt_length', 'custom_excerpt_length', 999 );

function excerpt_readmore($more) {
    return '...';
}
add_filter('excerpt_more', 'excerpt_readmore'); */

add_action('wp_loaded', 'remove_hooks');
function remove_hooks(){
	remove_action('mphb_render_loop_room_type_before_featured_image', '\MPHB\Views\LoopRoomTypeView::_renderFeaturedImageParagraphOpen', 10);
	remove_action('mphb_render_loop_room_type_after_featured_image', '\MPHB\Views\LoopRoomTypeView::_renderFeaturedImageParagraphClose', 10);
	remove_action('mphb_render_single_room_type_metas', '\MPHB\Views\SingleRoomTypeView::renderDefaultOrForDatesPrice', 30);
	remove_action('mphb_render_single_room_type_metas', '\MPHB\Views\SingleRoomTypeView::renderReservationForm', 50);
	remove_action('mphb_render_single_room_type_metas', '\MPHB\Views\SingleRoomTypeView::renderAttributes', 20);
	remove_action('mphb_render_single_room_type_metas', '\MPHB\Views\SingleRoomTypeView::renderCalendar', 40);
	
	/*
		Chekout Page
	*/
	remove_action('mphb_sc_checkout_form', '\MPHB\Views\Shortcodes\CheckoutView::renderCustomerDetails', 40);
	//add_action('mphb_cb_checkout_room_details', '\MPHB\Views\Shortcodes\CheckoutView::renderCustomerDetails', 21);
	add_action( 'mphb_sc_checkout_room_details', array( '\MPHB\Views\Shortcodes\CheckoutView', 'renderCustomerDetails' ), 21 );

	//add_action('mphb_render_single_room_type_metas', '\MPHB\Views\SingleRoomTypeView::renderDefaultOrForDatesPrice', 10);
}

add_action('mphb_sc_checkout_form', 'included_services', 31);
function included_services(){
	echo '<i>Price are include onetime airport pickup.</i>';
}

add_action('mphb_render_loop_room_type_before_featured_image', 'property_thumb_open_tag');
function property_thumb_open_tag(){
	echo '<div class="post-thumbnail mphb-loop-room-thumbnail">';
}

add_action('mphb_render_loop_room_type_after_featured_image', 'property_thumb_open_close');
function property_thumb_open_close(){
	echo '</div>';
}

add_filter('get_the_archive_title', 'tax_title_filter');
function tax_title_filter($title){
	if(is_tax('mphb_ra_location')){
		//$tax = get_taxonomy( get_queried_object()->taxonomy );
		return single_term_title( '', false );
	}
	
	return $title;
}

function arphabet_widgets_init() {
	
	register_sidebar( array(
		'name'          => 'Footer Left',
		'id'            => 'footer_left',
		'before_widget' => '<div class="footer-widget footer-left">',
		'after_widget'  => '</div>',
		'before_title'  => '<span class="widget-title">',
		'after_title'   => '</span>',
	) );
	
	register_sidebar( array(
		'name'          => 'Footer Middle',
		'id'            => 'footer_middle',
		'before_widget' => '<div class="footer-widget footer-middle">',
		'after_widget'  => '</div>',
		'before_title'  => '<span class="widget-title">',
		'after_title'   => '</span>',
	) );
	
	register_sidebar( array(
		'name'          => 'Footer Right',
		'id'            => 'footer_right',
		'before_widget' => '<div class="footer-widget footer-right">',
		'after_widget'  => '</div>',
		'before_title'  => '<span class="widget-title">',
		'after_title'   => '</span>',
	) );

}
add_action( 'widgets_init', 'arphabet_widgets_init' );

add_filter( 'comments_open', 'rvb_comments_open', 10, 2 );
function rvb_comments_open( $open, $post_id ) {
	$post = get_post( $post_id );

	if ( 'mphb_room_type' == $post->post_type )
		$open = true;

	return $open;
}

function rvb_move_comment_field_to_bottom( $fields ) {
	$comment_field = $fields['comment'];
	unset( $fields['comment'] );
	$fields['comment'] = $comment_field;
	return $fields;
}
add_filter( 'comment_form_fields', 'rvb_move_comment_field_to_bottom');

// disable for posts
add_filter('use_block_editor_for_post', '__return_false', 10);

// disable for post types
add_filter('use_block_editor_for_post_type', '__return_false', 10);

add_shortcode('get_latest_blog', 'get_latest_blog');
function get_latest_blog($atts){
	
	$atts = shortcode_atts( array(
		'posts_per_page'	=> 3,
		'related_to'		=> '',
	), $atts, 'bartag' );
	
	$paged = ( get_query_var( 'paged' ) ) ? absint( get_query_var( 'paged' ) ) : 1;

	$args = array(
		'posts_per_page' => $atts['posts_per_page'],
		'post_type' => 'post',
	);
	
	if(!empty($atts['related_to'])){
		$cats = wp_get_post_categories($atts['related_to']);
		if(!is_wp_error($cats)){
			$args['category__in'] = $cats;
			$args['post__not_in'] = array($atts['related_to']);
		}
	}

	$the_query = new WP_Query( $args );
	
	ob_start();
	?>
	<div class="blog-list">
		<?php
		if($the_query->have_posts()){
			while($the_query->have_posts()){
				$the_query->the_post();
				
				get_template_part( 'template-parts/content', 'relatedpost' );
			}
			
			wp_reset_postdata();
			
		}
		?>
	</div>
	<?php
	
	return ob_get_clean();
}

function modify_read_more_link() {
    return '<br><a class="more-link button" href="' . get_permalink() . '">'.__('Continue reading', 'rajavillabali').'</a>';
}
//add_filter( 'the_content_more_link', 'modify_read_more_link' );

function theme_slug_excerpt_length( $length ) {
        /* if ( is_admin() ) {
                return $length;
        } */
		global $post;
		
		if($post->post_type == 'post'){
			//return 65 is the current page is Magazine
			if(is_home()){
				return 65;
			}else{
				return 17;
			}
		}else{
			return 25;
		}
        
}
add_filter( 'excerpt_length', 'theme_slug_excerpt_length', 999 );

function wpdocs_excerpt_more( $more ) {
	global $post;
		
	if($post->post_type == 'post'){
		return sprintf( '...<br><a href="%1$s" class="more-link button">%2$s</a>',
			  esc_url( get_permalink( get_the_ID() ) ),
			  sprintf( __( 'Continue reading %s', 'rajavillabali' ), '<span class="screen-reader-text">' . get_the_title( get_the_ID() ) . '</span>' )
		);
	}else{
		return '...';
	}
}
add_filter( 'excerpt_more', 'wpdocs_excerpt_more' );


function rvb_comment($comment, $args, $depth) {
    if ( 'div' === $args['style'] ) {
        $tag       = 'div';
        $add_below = 'comment';
    } else {
        $tag       = 'li';
        $add_below = 'div-comment';
    }?>
    <<?php echo $tag; ?> <?php comment_class( empty( $args['has_children'] ) ? '' : 'parent' ); ?> id="comment-<?php comment_ID() ?>"><?php 
    if ( 'div' != $args['style'] ) { ?>
        <div id="div-comment-<?php comment_ID() ?>" class="comment-body"><?php
    } ?>
        <div class="comment-author vcard"><?php 
            if ( $args['avatar_size'] != 0 ) {
                echo get_avatar( $comment, $args['avatar_size'] ); 
            } 
            printf( __( '<cite class="fn">%s</cite>' ), get_comment_author_link() ); ?>
			<?php do_action('after_comment_author'); ?>
			<span class="comment-meta commentmetadata">
				<?php
					/* translators: 1: date, 2: time */
					printf( 
						__('%1$s at %2$s'), 
						get_comment_date(),  
						get_comment_time() 
					); ?>
				<?php 
				//edit_comment_link( __( '(Edit)' ), '  ', '' ); ?>
			</span>
        </div><?php 
        if ( $comment->comment_approved == '0' ) { ?>
            <em class="comment-awaiting-moderation"><?php _e( 'Your comment is awaiting moderation.' ); ?></em><br/><?php 
        } ?>
        

        <?php comment_text(); ?>

        <!--<div class="reply"><?php 
                comment_reply_link( 
                    array_merge( 
                        $args, 
                        array( 
                            'add_below' => $add_below, 
                            'depth'     => $depth, 
                            'max_depth' => $args['max_depth'] 
                        ) 
                    ) 
                ); ?>
        </div>--><?php 
    if ( 'div' != $args['style'] ) : ?>
        </div><?php 
    endif;
}

add_action( 'mphb_ra_location_edit_form_fields', 'rvba_taxonomy_custom_fields', 10, 2 );
add_action( 'mphb_ra_location_add_form_fields', 'rvba_taxonomy_custom_fields', 10, 2 ); 
function rvba_taxonomy_custom_fields($tag) {  
   // Check for existing taxonomy meta for the term you're editing  
    $t_id = $tag->term_id; // Get the ID of the term you're editing  
    $term_meta = get_option( "tax_meta_$t_id" ); // Do the check  
	//var_dump($term_meta);
?>  
  
<tr class="form-field">  
    <th scope="row" valign="top">  
        <label for="tax_id"><?php _e('Image'); ?></label>  
    </th>  
    <td>  
        <?php echo do_shortcode('[ez_wp_media_uploader wrapper_id="rvb-tax-image" field_name="term_meta{image}" image_id="'.$term_meta['image'].'" multiple="false" is_array_field_name="true"]'); ?> 
    </td>  
</tr>  
  
<?php  
} 

add_action( 'edited_mphb_ra_location', 'save_taxonomy_custom_fields', 10, 2 ); 
add_action( 'created_mphb_ra_location', 'save_taxonomy_custom_fields', 10, 2 );  
function save_taxonomy_custom_fields( $term_id ) {  
    if ( isset( $_POST['term_meta'] ) ) {  
        $t_id = $term_id;  
        $term_meta = get_option( "tax_meta_$t_id" );  
        $cat_keys = array_keys( $_POST['term_meta'] );  
            foreach ( $cat_keys as $key ){  
            if ( isset( $_POST['term_meta'][$key] ) ){  
                $term_meta[$key] = $_POST['term_meta'][$key];  
            }  
        }  
        //save the option array  
        update_option( "tax_meta_$t_id", $term_meta );  
    }  
}

add_action('wp_footer', 'floating_whatsapp');
function floating_whatsapp(){
	$wa_number = get_option('wa_number');
	if(!empty($wa_number)){
	?>
		<a class="floating-wa" target="_blank" href="https://api.whatsapp.com/send?phone=<?php echo $wa_number; ?>"><i class="fa fa-whatsapp" aria-hidden="true"></i></a>
	<?php
	}
}

add_shortcode('property_filter', 'property_filter');
function property_filter(){
	//$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
	ob_start();
	$inclusions = get_terms(array(
			'taxonomy' => 'mphb_ra_inclusion',
		));
	
	//var_dump($_GET);
	
	$today = new DateTime();
	
	$check_in = !empty($_GET['mphb_check_in_date']) ? $_GET['mphb_check_in_date'] : $today->format('Y-m-d');
	$today->add(new DateInterval('P1D'));
	$check_out = !empty($_GET['mphb_check_out_date']) ? $_GET['mphb_check_out_date'] : $today->format('Y-m-d');
	
	if(is_tax('mphb_ra_location')){
		$location = get_queried_object()->term_id;
	}else{
		$location = $_GET['mphb_attributes']['location'];
	}
	?>
	<div class="property-filter">
		<span class="h2"><?php _e('Filters', 'rajavillabali') ?></span>
		<form action="<?php echo get_page_link(2786); ?>">
			<input type="hidden" name="mphb_check_in_date" value="<?php echo $check_in; ?>">
			<input type="hidden" name="mphb_check_out_date" value="<?php echo $check_out; ?>">
			<input type="hidden" name="mphb_adults" value="<?php echo !empty( $_GET['mphb_adults'] ) ? $_GET['mphb_adults'] : 1; ?>">
			<input type="hidden" name="mphb_children" value="<?php echo !empty( $_GET['mphb_children'] ) ? $_GET['mphb_children'] : 0; ?>">
			<input type="hidden" name="mphb_attributes[location]" value="<?php echo $location; ?>">
			
			<?php
				if(!empty($inclusions)){
					$inclusion_selected = !empty($_GET['mphb_attributes']['inclusion']) ? $_GET['mphb_attributes']['inclusion'] : array();
					?>
					<div class="filter-section">
						<span class="filter-title"><?php _e('Inclusion', 'rajavillabali'); ?></span>
						<ul class="filter-list">
							<?php
							foreach($inclusions as $inc){
								?>
								<li>
									<input id="inclusion-<?php echo $inc->term_id; ?>" type="checkbox" name="mphb_attributes[inclusion][]" value="<?php echo $inc->term_id ?>" <?php echo in_array( $inc->term_id, $inclusion_selected ) ? 'checked' : ''; ?> >
									<label for="inclusion-<?php echo $inc->term_id; ?>"><?php echo $inc->name . ' - ' . $inc->term_id; ?></label>
								</li>
								<?php
							}
							?>
						</ul>
					</div>	
					<?php
				}
			?>
			
			<input type="submit" value="Filter" name="filter">
		</form>
	</div>
	<?php
	return ob_get_clean();
}

add_action('wp_footer', 'insert_inqyiry_form');
function insert_inqyiry_form(){
	if(is_singular('mphb_room_type')){
		global $post;
		?>
		<div id="inquiry-form" class="submit-property tmp-hide">
			<?php
				echo do_shortcode('[contact-form-7 id="3184" title="Inquiry Form"]');
			?>
		</div>
		<script>
			var inqVillaName = '<?php echo $post->post_title; ?>',
				inqVillaLink = '<?php echo get_permalink($post->ID); ?>';
		</script>
		<?php
	}
}

//email will be sent when customer send inquiry using the inquiry form
add_action('wp_ajax_inquiry_thankyou_email', 'inquiry_thankyou_email');
add_action('wp_ajax_nopriv_inquiry_thankyou_email', 'inquiry_thankyou_email');
function inquiry_thankyou_email(){
	$to = sanitize_email($_POST['to']);
	$name = sanitize_text_field($_POST['name']);
	$phone = sanitize_text_field( $_POST['phone'] );
	$msg = sanitize_textarea_field( $_POST['message'] );
	$villa_name	= sanitize_text_field( $_POST['villa-name'] );
	$villa_link	= sanitize_text_field( $_POST['villa-link'] );
	$check_in	= sanitize_text_field( $_POST['check-in'] );
	$check_out	= sanitize_text_field( $_POST['check-out'] );
	
	$subject = __('Thanks for your inquiry - Raja Villa Bali', 'rajavillabali');
	$message = '<p>'. sprintf( __('Thank you %s, <br> we have received your inquiry, we will get back to you as soon as possible', 'rajavillabali') , $name). '</p>';
	
	$message .= "<p><b>". __('Your inquiry details', 'rajavillabali'). "</b></p>
						<b>From</b>: {$name} ( {$to} )<br>
						<b>Phone</b>: {$phone}<br>
						<br>
						<b>Villa</b>: <a href='{$villa_link}'>{$villa_name}</a><br>
						<b>Check-in</b>: {$check_in}<br>
						<b>Check-out</b>: {$check_out}<br>
						<br>
						<b>Message</b>:<br>
						{$msg}";
	
	$headers[] = 'MIME-Version: 1.0';
	$headers[] = 'Content-type: text/html; charset=iso-8859-1';

	// Additional headers
	//$headers[] = 'To: Mary <mary@example.com>, Kelly <kelly@example.com>';
	$headers[] = 'From: Raja Villa Bali <info@rajavillabali.com>';

	// Mail it
	$status = wp_mail($to, $subject, $message, $headers);
	
	if($status){
		echo 'Terkirim';
	}else{
		echo 'Tidak Terkirim';
	}
	
	wp_die();
}

add_action('wp_ajax_find_accomodation', 'find_accomodation');
function find_accomodation(){
	$search = $_GET['q'];
	
	$accomodations = get_posts(array(
				'post_type'		=> 'mphb_room_type',
				's'				=> $search, 
			));
	
	$items = array();
	foreach($accomodations as $g){
		$items[] = array(
						'value' => $g->post_title,
						'id'	=> $g->ID,
					);
	}

	header('Content-type: application/x-javascript');
	echo $_GET['callback']."(".json_encode($items).")";
	
	wp_die();
}

add_action('wp_ajax_find_hd_accomodation', 'find_hd_accomodation');
function find_hd_accomodation(){
	$search = $_GET['q'];
	
	$hds = get_posts(array(
				'post_type'			=> 'hot-deal',
				'posts_per_page'	=> -1,
				'post_status'		=> 'any',
				'meta_query'		=> array(
										'key'		=> 'rvb_hd_date_end',
										'compare'	=> '>',
										'type'		=> 'DATE',
										'value'		=> date('Y-m-d'),
									)
			));
	
	
	$args = array(
				'post_type'		=> 'mphb_room_type',
				's'				=> $search, 
			);
			
	if(!empty( $hds )){
		$exclude_properties = array();
		
		foreach($hds as $hd){
			$properties = get_post_meta($hd->ID, 'rvb_hd_properties', true);
			if(!empty($properties)){
				$exclude_properties = array_merge($exclude_properties, $properties);
			}
		}
		
		if(!empty($exclude_properties)){
			$args['post__not_in'] = $exclude_properties;
		}
	}
	
	$accomodations = get_posts($args);
	
	$items = array();
	foreach($accomodations as $g){
		$items[] = array(
						'value' => $g->post_title,
						'id'	=> $g->ID,
					);
	}

	header('Content-type: application/x-javascript');
	echo $_GET['callback']."(".json_encode($items).")";
	
	wp_die();
}

//Send Booking link to customer by admin
add_action('wp_ajax_send_booking_link', 'send_booking_link');
function send_booking_link(){
	
	$c_email = sanitize_email($_POST['c_email']);
	$c_name = sanitize_text_field($_POST['c_name']);
	$check_in = sanitize_text_field($_POST['check-in']);
	$check_out = sanitize_text_field($_POST['check-out']);
	$accomodation_id = sanitize_text_field($_POST['accomodation_id']);
	$villa_name = get_the_title($accomodation_id);
	
	$email_template = file_get_contents(get_template_directory().'/email-templates/default.html');
	$subject = sprintf( __('Book %1$s now - %2$s'), $villa_name, get_bloginfo('name'));
	
	$email_content = "<p>Hi {$c_name},<br><br> Your dates selection are available, you can continue to book the accomodation using the button below.</p>";
	$email_content .= "<p><b style='font-size: 1.2em;
							margin-bottom: 10px;
							display: inline-block;
							margin-top: 30px;'>Booking Details</b><br>
							<b>Accommodation</b>: <a href='".get_permalink($accomodation_id)."'>{$villa_name}</a><br>
							<b>Check-in</b>: {$check_in}<br>
							<b>Check-out</b>: {$check_out}
						</p>
						<a style='display: inline-block; padding: 12px 24px; background: #31adad; font-size: 1.2em;color: #fafafa;
								text-decoration: none;' href='".get_page_link(3187)."?vid={$accomodation_id}&ciid={$check_in}&coid={$check_out}'>Book Now</a>";
	$email_title = sprintf( __('%s is available', 'rajavillabali'), $villa_name);
	
	$search = array('{email_title}', '{email_content}');
	$replace = array($email_title, $email_content);
	$email = str_replace($search, $replace, $email_template);
	
	$headers[] = 'MIME-Version: 1.0';
	$headers[] = 'Content-type: text/html; charset=iso-8859-1';

	// Additional headers
	//$headers[] = 'To: Mary <mary@example.com>, Kelly <kelly@example.com>';
	$headers[] = 'From: Raja Villa Bali <info@rajavillabali.com>';

	// Mail it
	$status = wp_mail($c_email, $subject, $email, $headers);
	
	if($status){
		echo '<div class="notice notice-success is-dismissible">
				<p>Booking link has been sent successfully</p>
			</div>';
	}else{
		echo '<div class="notice notice-warning is-dismissible">
				<p>Failed to send booking link, please try again later or contact you administrator.</p>
			</div>';
	}
	
	wp_die();
}

function rvb_get_property_contact($rooms){
	//return get_post_meta();
	//foreach($rooms as $room){
	$accomodation_id = $rooms[0]->getRoomTypeId();
	$phone = get_post_meta($accomodation_id, 'rvb_property_contact_phone', true);
	$email = get_post_meta($accomodation_id, 'rvb_property_contact_email', true);
	$return = $phone .'<br>'.$email;
	//}
	return $return; // print_r($rooms, true);
}

add_filter('mphb_email_booking_tags', 'rvb_add_mphb_email_tags', 10, 1);
function rvb_add_mphb_email_tags($bookingTags){
	$bookingTags[] = array(
				'name'			 => 'property_contact',
				'description'	 => __( 'Show property contact', 'motopress-hotel-booking' ),
			);
	exit();
	return $bookingTags;
}

add_action('mphb_booking_confirmed_with_payment', 'send_booking_confirmed_to_property_owner', 10, 1);
//add_action('wp_loaded', 'send_booking_confirmed_to_property_owner');
function send_booking_confirmed_to_property_owner($booking){
	//if(empty($_GET['test_mail'])) return;
		
	/* $booking = MPHB()->getBookingRepository()->findById( 3215 );

	if ( !$booking ) {
		echo 'booking sing ade';
		exit();
	} */
		
	$email_template = file_get_contents(get_template_directory().'/email-templates/default.html');
	$subject = __('New Booking - Raja Villa Bali', 'rajavillabali');
	
	$email_content = "<p>".sprintf( __('Congratulation, you have new booking from %s', 'rajavillabali'), get_bloginfo('name') )."</p>";
	ob_start();
	\MPHB\Views\BookingView::renderCheckInDateWPFormatted( $booking );
	$check_in = ob_get_clean();
	
	ob_start();
	\MPHB\Views\BookingView::renderCheckOutDateWPFormatted( $booking );
	$check_out = ob_get_clean();
	
	$email_content .= "<h4>Details of booking</h4>
						Booking ID: #{$booking->getId()}<br>
						Check-in: {$check_in}<br>
						Check-out: {$check_out}<br>";
	
	$reservedRooms	 = $booking->getReservedRooms();
	$accomodation_id = $reservedRooms[0]->getRoomTypeId();
	$roomType	 = MPHB()->getRoomTypeRepository()->findById( $accomodation_id );
					//$roomType	 = apply_filters( '_mphb_translate_room_type', $roomType, $this->booking->getLanguage() );
					//$replaceText = ( $roomType ) ? $roomType->getTitle() : '';
	$email_content .= "<h4>Accommodation</h4>
						Guest: {$reservedRooms[0]->getAdults()}<br>
						Accommodation: {$roomType->getTitle()}<br>";
	
	$email_content .= "<h4>Customer Info</h4>
						Name: ".$booking->getCustomer()->getFirstName()." ".$booking->getCustomer()->getLastName()."<br>
						Email: ".$booking->getCustomer()->getEmail()."<br>
						Phone: ".$booking->getCustomer()->getPhone()."<br>
						Note: <br>".$booking->getNote();
	
	$email_title = __('New Booking', 'rajavillabali');
	
	$search = array('{email_title}', '{email_content}');
	$replace = array($email_title, $email_content);
	$email = str_replace($search, $replace, $email_template);
	
	$headers[] = 'MIME-Version: 1.0';
	$headers[] = 'Content-type: text/html; charset=iso-8859-1';
	
	$villa_owner_email = get_post_meta($accomodation_id, 'rvb_property_contact_new_booking_email', true);
	// Additional headers
	//$headers[] = 'To: Mary <mary@example.com>, Kelly <kelly@example.com>';
	$headers[] = 'From: Raja Villa Bali <info@rajavillabali.com>';
	
	
	// Mail it
	$status = $status = wp_mail($villa_owner_email, $subject, $email, $headers);
}

add_action('wp_loaded', 'check_things');
function check_things(){
	if(!empty($_GET['check_comment'])){
		rvb_add_new_review();
		exit();
	}
	
	if(!empty($_GET['check_hd'])){
		$hds = get_posts(array(
				'post_type'			=> 'hot-deal',
				'posts_per_page'	=> -1,
				'post_status'		=> 'any',
				'meta_query'		=> array(
										'key'		=> 'rvb_hd_date_end',
										'compare'	=> '>',
										'type'		=> 'DATE',
										'value'		=> date('Y-m-d'),
									)
			));
	
			var_dump($hds);
			
			$args = array(
						'post_type'		=> 'mphb_room_type',
						's'				=> $search, 
					);
					
			if(!empty( $hds )){
				$exclude_properties = array();
				
				foreach($hds as $hd){
					$properties = get_post_meta($hd->ID, 'rvb_hd_properties', true);
					var_dump($properties);
					if(!empty($properties)){
						$exclude_properties = array_merge($exclude_properties, $properties);
					}
				}
				
				if(!empty($exclude_properties)){
					$args['post__not_in'] = $exclude_properties;
				}
				
			}
		
			
		exit();
	}
	
	if(!empty($_GET['check_emails'])){
		$emails = get_email_blast_receivers();
		var_dump($emails);
		exit();
	}
}

add_shortcode('get_hot_deals', 'get_hot_deals');
function get_hot_deals(){
	$hds = get_posts(array(
				'post_type'			=> 'hot-deal',
				'posts_per_page'	=> -1,
				'meta_query'		=> array(
										'key'		=> 'rvb_hd_date_end',
										'compare'	=> '>',
										'type'		=> 'DATE',
										'value'		=> date('Y-m-d'),
									)
			));
	
	if(!empty($hds)){
		ob_start();
		if(count($hds) > 1){
			?>
			<div class="hot-deals-list">
				<div class="row">
					<?php
					foreach($hds as $hd){
						?>
						<div class="col-sm-6">
							<a class="post-thumbnail" href="<?php echo get_the_permalink($hd->ID); ?>" aria-hidden="true" tabindex="-1">
								<?php
									echo get_the_post_thumbnail($hd->ID, 'property-thumb');
								?>
							</a>
						</div>
						<?php
					}
				?>
				</div>
			</div>
			<?php
		}else{
			$properties = get_post_meta($hds[0]->ID, 'rvb_hd_properties', true);
			if(!empty($properties)){
				echo do_shortcode('[mphb_rooms ids="'.implode(',', $properties).'"]');
			}else{
				echo 'There is no properties selected in the hot deal program';
			}
		}
		return ob_get_clean();
	}
	
	return 'There is no hot deal program at the moment';
}

function get_hot_deal_discount($accomodation_id = null){
	if(empty($accomodation_id)){
		global $post;
		$accomodation_id = $post->ID;
	}
	
	
	$hot_deal_id = get_post_meta($accomodation_id, 'hot_deal', true);
	//var_dump($hot_deal_id);
	//Check if hot deal program still valid, not expired
	$valid_hd = get_posts(array(
				'post_type'			=> 'hot-deal',
				'posts_per_page'	=> 1,
				'p'					=> $hot_deal_id,
				'meta_query'		=> array(
										'key'		=> 'rvb_hd_date_end',
										'compare'	=> '>',
										'type'		=> 'DATE',
										'value'		=> date('Y-m-d'),
									)
			));
	//var_dump($valid_hd);
	if(!empty($valid_hd)){
		$properties = get_post_meta( $valid_hd[0]->ID, 'rvb_hd_properties', true );
		if(in_array($accomodation_id, $properties)){
			$discount = get_post_meta($valid_hd[0]->ID, 'rvb_hd_date_discount', true);
			return $discount;
		}
	}
	
	return false;
}

function rvb_send_email($to, $subject, $email_title, $email_content){
	
	$email_template = file_get_contents(get_template_directory().'/email-templates/default.html');
	$search = array('{email_title}', '{email_content}');
	$replace = array($email_title, $email_content);
	$email = str_replace($search, $replace, $email_template);
	
	$headers[] = 'MIME-Version: 1.0';
	$headers[] = 'Content-type: text/html; charset=iso-8859-1';
	// Additional headers
	//$headers[] = 'To: Mary <mary@example.com>, Kelly <kelly@example.com>';
	$headers[] = 'From: Raja Villa Bali <info@rajavillabali.com>';
	
	
	// Mail it
	$status = wp_mail($to, $subject, $email, $headers);
	
	return $status;
}

function get_email_blast_receivers(){
	global $wpdb;
	$sql = "select e.meta_value as email from ".$wpdb->posts." b 
				INNER JOIN ".$wpdb->postmeta." e ON ( e.post_id = b.ID AND e.meta_key='mphb_email' )
			WHERE b.post_type='mphb_booking' AND b.post_status='confirmed' AND e.meta_value <> ''
			GROUP BY e.meta_value";
	
	$emails = $wpdb->get_results($sql, 'ARRAY_A' );
	
	return array_values($emails);
}

add_action('wp_ajax_send_email_blast_ajax', 'rvb_send_email_blast');
function rvb_send_email_blast(){
	
	set_time_limit(0);
	
	
	$template_path = get_template_directory();
	$emails = get_email_blast_receivers();
	
	$email_title = $_POST['email_title'];
	$email_text	= $_POST['email_text'];
	$subject	= $_POST['subject'];
	$hot_deals	= $_POST['hot_deals'];
	$test_email	= $_POST['test_email'];
	
	$separator = '<p style="text-align:center; margin-bottom: 60px;"><span style="border-top-style: dotted;
								border-top-width: 5px;
								border-top-color: #d7ad3f;
								width: 10%;
								display: inline-block;">
				</span></p>';
	$email_content = 'masuk email';
	if(!empty($email_text)){
		$email_content = '<p style="text-align:center;">'.$email_text.'</p>' . $separator;
	}
	
	
	foreach($hot_deals as $hd){
		$link = get_permalink($hd);
		$img_url = get_the_post_thumbnail_url($hd, 'blog-small-thumb');
		$email_content .= '<p align="center" style="margin-bottom: 60px;"><a href="'.$link.'"><img src="'.$img_url.'"></a><br>
								<a style="display: inline-block; padding: 12px 24px; background: #31adad; font-size: 1.2em;color: #fafafa;
								text-decoration: none;" href="'.$link.'">See Offer</a>
							</p>';
	}
	
	$email_result = array();
	
	if(empty($test_email)){
		$total_email = count($emails);
		$progress_step = 100 / $total_email;
		$progress = 0;
		
		foreach($emails as $email){
			
			$email_result[$email] = rvb_send_email($email, $subject, $email_title, $email_content);
			
			$progress += $progress_step;
			file_put_contents($template_path . '/progress.json', json_encode(array('progress'=> round($progress))));
		}
	}else{
		//send test email
		$email_title .= ' - Test';
		$subject .= '- Test';
		$email_result[$test_email] = rvb_send_email($test_email, $subject, $email_title, $email_content);
		file_put_contents($template_path . '/progress.json', json_encode(array('progress'=> round(100))));
	}
	
	print_r($email_result);
	echo $email_content;
	wp_die();
}

add_action('wp_ajax_reset_progress', 'reset_progress');
function reset_progress(){
	file_put_contents(get_template_directory() . '/progress.json', json_encode(array('progress'=>0)));
	
	wp_die();
}

//add Review/Comment using ajax
add_action('wp_ajax_nopriv_rvb_add_new_review', 'rvb_add_new_review');
add_action('wp_ajax_rvb_add_new_review', 'rvb_add_new_review');
function rvb_add_new_review(){
	//global $post, $current_user; //for this example only :)

	$commentdata = array(
		'comment_post_ID' => $_POST['accomodation_id'], // to which post the comment will show up
		'comment_author' => $_POST['customer_name'], //fixed value - can be dynamic 
		'comment_author_email' => $_POST['email'], //fixed value - can be dynamic 
		'comment_author_url' => '', //fixed value - can be dynamic 
		'comment_content' => $_POST['comment'], //fixed value - can be dynamic 
		'comment_type' => '', //empty for regular comments, 'pingback' for pingbacks, 'trackback' for trackbacks
		'comment_parent' => 0, //0 if it's not a reply to another comment; if it's a reply, mention the parent comment ID here
		//'user_id' => $current_user->ID, //passing current user ID or any predefined as per the demand
	);

	//Insert new comment and get the comment ID
	$comment_id = wp_new_comment( $commentdata, true );
	
	if(!is_wp_error($comment_id)){
		$rating = intval( $_POST['rating'] );
		add_comment_meta( $comment_id, 'rating', $rating );
		
		echo '<div class="notice success">'.__('Thank You, your review has been sent successfully.', 'rajavillabali').'</div>';
	}else{
		echo '<div class="notice error">'.__('We apologize, your review was not sent successfully, please try again later.', 'rajavillabali').'</div>';
	}
	
	//var_dump($comment_id);
	
	wp_die();
}