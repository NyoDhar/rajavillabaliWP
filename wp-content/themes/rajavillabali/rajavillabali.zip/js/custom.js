(function( $ ) {
	$.fn.addLoadingLayer = function(options){
		var settings = $.extend({
            size: "fa-3x",
        }, options );
		
		var spinner = typeof adminpage != 'undefined' ? '<span class="load spinner is-active"></span>' : '<i class="load fa fa-spinner fa-pulse '+settings.size+'"></i>';
		
		var layer = "<div class='loading-data'>"+spinner+"</div>";
		this.append(layer);
		this.css('position','relative');
		return this;
	};
	
	$.fn.removeLoadingLayer = function(){
		this.find('.loading-data').remove();
		return this;
	};
}( jQuery ));

jQuery(document).ready(function($){
	$("#masthead").sticky({ topSpacing: 0 });
	$(".bookbox").sticky({ topSpacing: 105 });
	
	if($('.open-change-search').length){
		$('.open-change-search').click(function(e){
			e.preventDefault();
			if($('.change-search').is(':visible')){
				$('.change-search').slideUp();
				$(this).text($(this).data('text'));
			}else{
				$('.change-search').slideDown();
				$(this).text($(this).data('cancel'));
			}
		});
	}
	
	/* function init_owl() {
		$(".owl-carousel[data-carousel=owl]").each( function(){
			var config = {
				loop: false,
				nav: $(this).data( 'nav' ),
				dots: false, //$(this).data( 'pagination' ),
				items: 4,
				navSpeed: 800,
				navText: ['<i class="fa fa-chevron-left" aria-hidden="true"></i>', '<i class="fa fa-chevron-right" aria-hidden="true"></i>']
			};
		
			var owl = $(this);
			if( $(this).data('items') ){
				config.items = $(this).data( 'items' );
			}
			if( $(this).data('loop') ){
				config.loop = true;
			}
			if ($(this).data('margin')) {
				config.margin = $(this).data('margin');
			} else {
				config.margin = 30;
			}
			if ($(this).data('large')) {
				var desktop = $(this).data('large');
			} else {
				var desktop = config.items;
			}
			if ($(this).data('medium')) {
				var medium = $(this).data('medium');
			} else {
				var medium = config.items;
			}
			if ($(this).data('smallmedium')) {
				var smallmedium = $(this).data('smallmedium');
			} else {
				var smallmedium = config.items;
			}
			if ($(this).data('extrasmall')) {
				var extrasmall = $(this).data('extrasmall');
			} else {
				var extrasmall = 2;
			}
			if ($(this).data('verysmall')) {
				var verysmall = $(this).data('verysmall');
			} else {
				var verysmall = 1;
			}
			config.responsive = {
				0:{
					items:verysmall
				},
				320:{
					items:extrasmall
				},
				768:{
					items:smallmedium
				},
				980:{
					items:medium
				},
				1280:{
					items:desktop
				}
			}
			if ( $('html').attr('dir') == 'rtl' ) {
				config.rtl = true;
			}
			$(this).owlCarousel( config );
			// owl enable next, preview
			var viewport = jQuery(window).width();
			var itemCount = jQuery(".owl-item", $(this)).length;

			if(
				(viewport >= 1280 && itemCount <= desktop) //desktop
				|| ((viewport >= 980 && viewport < 1280) && itemCount <= medium) //desktop
				|| ((viewport >= 768 && viewport < 980) && itemCount <= smallmedium) //tablet
				|| ((viewport >= 320 && viewport < 768) && itemCount <= extrasmall) //mobile
				|| (viewport < 320 && itemCount <= verysmall) //mobile
			) {
				$(this).find('.owl-prev, .owl-next').hide();
			}
		} );
	}
	
	setTimeout(function(){
		init_owl();
	}, 50); */
	
	/* $('.property-gallery-index .thumb-link').each(function(e){
		$(this).click(function(event){
			event.preventDefault();
			$('.property-gallery-preview-owl').trigger("to.owl.carousel", [e, 800, true]);
			
			return false;
		});
	});
	$('.property-gallery-preview-owl').on('changed.owl.carousel', function(event) {
		setTimeout(function(){
			var index = 0;
			$('.property-gallery-preview-owl .owl-item').each(function(i){
				if ($(this).hasClass('active')){
					index = i - 3;
				}
			});
			
			$('.property-gallery-index .thumb-link').removeClass('active');
			$('.property-gallery-index .owl-item').eq(index).find('.thumb-link').addClass('active');
		},50);
	}); */
	
	if($('.open-submit-form a').length){
		$('.open-submit-form a').click(function(e){
			e.preventDefault();
			$('.submit-property').show();
			$('body').css('overflow-y', 'hidden');
		});
		
		$('.submit-property-form .head .close').click(function(){
			$('.submit-property').hide();
			$('body').css('overflow-y', 'auto');
		});
	}
	
	if($('#open-inquiry').length){
		
		$('#open-inquiry').click(function(e){
			e.preventDefault();
			$('#inq-villa-link').val(inqVillaLink);
			$('#inq-villa-name').val(inqVillaName);
			$('#inq-check-in').val($('.bookbox input.mphb_room_type_check_in_datepicker').val());
			$('#inq-check-out').val($('.bookbox .mphb-check-out-date-wrapper input.mphb-datepick').val());
			
			$('#inquiry-form').show();
			$('body').css('overflow-y', 'hidden');
		});
		
		$('#inquiry-form .head .close').click(function(){
			$('#inquiry-form').hide();
			$('body').css('overflow-y', 'auto');
		});
	}
	
	//will be sent to customer on inquiry sent successfully
	document.addEventListener( 'wpcf7mailsent', function( event ) {
		if ( '3184' == event.detail.contactFormId ) {
			console.log($('#inq-villa-name').val());
			var ajaxData = {
						'action'			: 'inquiry_thankyou_email',
						'to'				: $('#inq-email').val(),
						'name'				: $('#inq-full-name').val(),
						'phone'				: $('#inq-phone').val(),
						'message'			: $('#inq-message').val(),
						'villa-name'		: $('#inq-villa-name').val(),
						'villa-link'		: $('#inq-villa-link').val(),
						'check-in'			: $('#inq-check-in').val(),
						'check-out'			: $('#inq-check-out').val(),
					};
			
			$.ajax({
				url		: ajaxurl,
				type	: 'POST',
				data	: ajaxData,
				success	: function(e){
					console.log(e);
				},
				error	: function( jqxhr, status){
					console.log(status);
				}
			});
		}
	}, false );
	
	if($('.photos').length){
		$('.photos').magnificPopup({
		  delegate: 'a', // child items selector, by clicking on it popup will open
		  type: 'image',
		  gallery:{enabled:true},
		  // other options
		});
	}
	
	if($('.the-review-form').length){
		$('#commentform').submit(function(e){
			e.preventDefault();
			$(this).addLoadingLayer();
			var ajaxData = {
							'action'			: 'rvb_add_new_review',
							'accomodation_id'	: $('#accomodation-id').val(),
							'customer_name'		: $('#author').val(),
							'email'				: $('#email').val(),
							'comment'			: $('#comment').val(),
							'rating'			: $('input[name="rating"]:checked').val(),
						};
			
			$.ajax({
				url		: ajaxurl,
				type	: 'POST',
				data	: ajaxData,
				success	: function(e){
					$('#rvb-comment-notice').html(e);
				},
				complete: function(){
					$('#commentform').removeLoadingLayer();
				},
				error	: function(e, ee){
					console.log(ee);
				}
			});
		});
	}
	
});