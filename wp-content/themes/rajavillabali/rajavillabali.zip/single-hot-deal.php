<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package rajavillabali
 */

get_header();
?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main page">
			
			<?php if ( have_posts() ) : ?>
			<?php
				$bg = '';
				$post_id = get_the_ID();
				
				if(has_post_thumbnail()){
					$src = get_the_post_thumbnail_url($post_id, 'blog-big-thumb');
					$bg = 'style="background-image: url('. esc_url( $src ).');"';
				}else{
					if(has_header_image()){
						$bg = 'style="background-image: url('. esc_url( get_header_image() ).');"';
					}
				}
			?>
			<header class="page-header entry-header bg big" <?php echo $bg; ?>>
				
				<div class="floating-bot">
					<div class="container">
						<?php
						the_title( '<h1 class="page-title entry-title">', '</h1>' );
						
						if(function_exists('bcn_display') && !is_front_page()){		
							?>
							<div class="breadcrumbs" typeof="BreadcrumbList" vocab="https://schema.org/">
								<?php bcn_display(); ?>
							</div>
							
							<?php 
						}
						?>
					</div>
				</div>
			</header><!-- .page-header -->
			
			<article id="post-<?php the_ID(); ?>" <?php post_class('post'); ?>>
				<div class="container">
						<?php
							$properties = get_post_meta($post_id, 'rvb_hd_properties', true);
							if(!empty($properties)){
								echo do_shortcode('[mphb_rooms ids="'.implode(',', $properties).'"]');
							}else{
								echo 'There is no properties selected in the hot deal program';
							}
						?>
				</div>
				
				<?php
				endif;
				?>
			</article>
		</main><!-- #main -->
	</div><!-- #primary -->

<?php
//get_sidebar();
get_footer();