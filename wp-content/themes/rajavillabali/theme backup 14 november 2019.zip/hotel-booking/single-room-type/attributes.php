<?php

if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<h2 class="rvb-ammenities"><?php _e('Ammenities', 'rajavillabali'); ?></h2>
<?php

/**
 * @hooked \MPHB\Views\SingleRoomTypeView::renderAttributesTitle	- 10
 * @hooked \MPHB\Views\SingleRoomTypeView::renderAttributesListOpen	- 20
 */
//do_action( 'mphb_render_single_room_type_before_attributes' );
?>

<?php

/**
 * @hooked \MPHB\Views\SingleRoomTypeView::renderAdults				- 10
 * @hooked \MPHB\Views\SingleRoomTypeView::renderChildren			- 20
 * @hooked \MPHB\Views\SingleRoomTypeView::renderFacilities			- 30
 * @hooked \MPHB\Views\SingleRoomTypeView::renderView				- 40
 * @hooked \MPHB\Views\SingleRoomTypeView::renderSize				- 50
 * @hooked \MPHB\Views\SingleRoomTypeView::renderBedType			- 60
 * @hooked \MPHB\Views\SingleRoomTypeView::renderCategories			- 70
 * @hooked \MPHB\Views\SingleRoomTypeView::renderCustomAttributes	- 80
 */
//do_action( 'mphb_render_single_room_type_attributes' );
?>

<?php

/**
 * @hooked \MPHB\Views\SingleRoomTypeView::renderAttributesListClose - 10
 */
//do_action( 'mphb_render_single_room_type_after_attributes' );

//echo get_the_term_list( get_the_ID(), 'mphb_room_type_facility', '<ul class="mphb_room_type_facility"><li>', '</li><li>', '</li></ul>' );
$terms = wp_get_post_terms(get_the_ID(), 'mphb_room_type_facility');

if(!is_wp_error($terms)){
	?>
	<ul class="mphb_room_type_facility">
	<?php
	foreach($terms as $term){
		?>
		<li><i class="fa fa-check-circle-o" aria-hidden="true"></i> <?php echo $term->name; ?></li>
		<?php
	}
	?>
	</ul>
	<?php
}
?>
