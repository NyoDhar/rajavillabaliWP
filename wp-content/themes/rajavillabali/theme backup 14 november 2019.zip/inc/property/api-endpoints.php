<?php
add_action( 'rest_api_init', function () {
	// (?:/(?P<author>\d+))?  : cara menambahkan optional parameters pada api endpoint
  register_rest_route( 'rvbali/v1', '/accomodation/(?P<id>\d+)(?:/(?P<author>\d+))?', array(
    'methods' => 'GET',
    'callback' => 'my_awesome_func',
  ) );
  
} );

function my_awesome_func( $data ) {
	$args = array(
			'post_type'	=> 'mphb_room_type',
			'p' 		=> $data['id'], // parameter yg digunakan sama dengan wp_query, referensi ne dini: https://developer.wordpress.org/reference/classes/wp_query/#parameters
		  );
	
	if(!empty($data['author'])){
		$args['author'] = $data['author']; // optional parameter
	}
		  
  $posts = get_posts( $args );
 
  if ( empty( $posts ) ) { 
	return new WP_Error( 'no_post', 'Puyuh bruhh', array( 'status' => 404 ) );
  }

//jika jenis data yg direturn bukan STRING, maka data akan secara otomatis akan di encode menjadi json oleh wp core
  return $posts;
}

/* 
	endpoint contoh:
	
	1. Tanpa parameter author, hanya passing parameter ID
	http://localhost/rajavillabali/en/wp-json/rvbali/v1/accomodation/2815
	
	
	2. Dengan Parameter ID dan author
	http://localhost/rajavillabali/en/wp-json/rvbali/v1/accomodation/2815/1
	
	
	Referensi:
	
	1. Wordpress API custom endpoint
	https://developer.wordpress.org/rest-api/extending-the-rest-api/adding-custom-endpoints/
	
	2. Wordpress API Authentication
	https://developer.wordpress.org/rest-api/using-the-rest-api/authentication/
	ajak di video ne ci kirim di WA to mase yok
	
	3. Wordpress WP_Query
	https://developer.wordpress.org/reference/classes/wp_query/
	
*/