(function( $ ) {
	$.fn.addLoadingLayer = function(options){
		var settings = $.extend({
            size: "fa-3x",
        }, options );
		
		var spinner = typeof adminpage != 'undefined' ? '<span class="load spinner is-active"></span>' : '<i class="load fa fa-spinner fa-pulse '+settings.size+'"></i>';
		
		var layer = "<div class='loading-data'>"+spinner+"</div>";
		this.append(layer);
		this.css('position','relative');
		return this;
	};
	
	$.fn.removeLoadingLayer = function(){
		this.find('.loading-data').remove();
		return this;
	};
}( jQuery ));

jQuery(document).ready(function($){
	if($('.rvb-datepicker').length){
		$('.rvb-datepicker').datepicker({
			dateFormat: "yy-mm-dd",
		});
	}
	if($('#find-accomodation').length){
		 $( "#find-accomodation" ).autocomplete({
			source: function( request, response ) {
				$.ajax({
					type: 'GET',
				  url: ajaxurl,
				  dataType: "jsonp",
				  data: {
					'action': 'find_accomodation',
					q		: request.term,
				  },
				  success: function( data ) {
					response( data );
				  },
				  error : function(e, ee, eee){
					  console.log(e);
					  console.log(ee);
					  console.log(eee);
				  }
				});
			},
			minLength: 3,
			select: function( event, ui ) {
				event.preventDefault();
				console.log(ui);
				$('#find-accomodation').val(ui.item.value);
				$('input[name="accomodation_id"]').val(ui.item.id);
			}
		});
	}
	
	if($('#rvb_hd_properties_search').length){
		bind_remove_hd_property();
		
		$('#rvb_hd_add').click(function(){
			var property_id = $('#rvb_hd_properties_search').val();
			console.log( property_id );
			
			if( property_id ){
				var element = "<li><input type='hidden' name='rvb_hd_properties[]' value='"+$('#rvb_hd_properties_search_id').val()+"'>"
							+ property_id + " <span class='remove'>&times;</span>"
							+ "</li>";
				
				$('#rvb_hd_properties').append( element );
				bind_remove_hd_property();
				$('#rvb_hd_properties_search').val('');
				$('#rvb_hd_properties_search_id').val('');
			}
		});
		
		 $( "#rvb_hd_properties_search" ).autocomplete({
			source: function( request, response ) {
				$.ajax({
					type: 'GET',
				  url: ajaxurl,
				  dataType: "jsonp",
				  data: {
					'action': 'find_hd_accomodation',
					q		: request.term,
				  },
				  success: function( data ) {
					response( data );
				  },
				  error : function(e, ee, eee){
					  console.log(e);
					  console.log(ee);
					  console.log(eee);
				  }
				});
			},
			minLength: 3,
			select: function( event, ui ) {
				event.preventDefault();
				console.log(ui);
				$('#rvb_hd_properties_search').val(ui.item.value);
				$('#rvb_hd_properties_search_id').val(ui.item.id);
			}
		});
	}
	
	function bind_remove_hd_property(){
		$('#rvb_hd_properties li .remove').unbind().click(function(){
			$(this).parent().remove();
		});
	}
	
	if($('#send-booking-link').length){
		$('#send-booking-link').submit(function(e){
			e.preventDefault();
			$(this).addLoadingLayer();
			
			var ajaxData = {
					'action'	: 'send_booking_link',
					'c_email'	: $('input[name="c_email"]').val(),
					'c_name'	: $('input[name="c_name"]').val(),
					'check-in'	: $('input[name="check-in"]').val(),
					'check-out'	: $('input[name="check-out"]').val(),
					'accomodation_id'	: $('input[name="accomodation_id"]').val(),
				};
				
			$.ajax({
				url		: ajaxurl,
				data	: ajaxData,
				type	: 'POST',
				success	: function(e){
					console.log(e);
					
					$('#wpbody-content .wrap').prepend(e);
					$('#send-booking-link')[0].reset();
				},
				error	: function(e, ee){
					console.log(ee);
				},
				complete : function(){
					$('#send-booking-link').removeLoadingLayer();
				}
			});
		});
	}
	
	if($('form#send-email-blast').length){
		var progressInterval;
		$('form#send-email-blast').submit(function(e){
			e.preventDefault();
			startProgressBar();
			
			var hotDeals = [];
			$('.hot-deals:checked').each(function () {
				   hotDeals.push($(this).val());
			  });
			var ajaxData = {
					'action'	: 'send_email_blast_ajax',
					'email_title'	: $('input[name="email_title"]').val(),
					'email_text'	: $('#email_text').val(),
					'subject'	: $('input[name="email_subject"]').val(),
					'hot_deals'	: hotDeals,
					'test_email'	: $('#test-email').val(),
				};
			
			console.log(ajaxData);
			$.ajax({
				url		: ajaxurl,
				type	: 'POST',
				data	: ajaxData,
				cache	: false,
				success	: function(e){
					//console.log(JSON.parse(e));
					console.log(e);
				}
			});
		});
		
		$('#test-email').blur(function(){
			if($(this).val() != ''){
				$('#submit-email-blast').val('Send Test Email');
			}else{
				$('#submit-email-blast').val('Send');
			}
		});
	}
	
	function startProgressBar(){
		var progressbar = $( "#progressbar" ),
		progressLabel = $( ".progress-label" );
		progressbar.show();
		
		progressbar.progressbar({
		  value: false,
		  change: function() {
			progressLabel.text( progressbar.progressbar( "value" ) + "%" );
		  },
		  complete: function() {
			progressLabel.text( "Complete!" );
			clearInterval(progressInterval);
			$.ajax({
				url		: ajaxurl,
				data	: {'action': 'reset_progress'},
			});
		  }
		});
		
		progressInterval = setInterval( function(){
			$.getJSON( progressPath + '?_=' + new Date().getTime(), function( data ) {
				console.log(data);
				progressbar.progressbar( "value", data.progress );
			});
		}, 1000 );
	}
	
});